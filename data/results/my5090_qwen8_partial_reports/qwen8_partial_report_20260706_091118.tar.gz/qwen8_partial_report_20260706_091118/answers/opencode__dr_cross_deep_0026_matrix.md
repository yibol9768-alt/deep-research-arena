(opencode produced no report after 2s, exit=255)

--- ssh stdout tail ---


--- ssh stderr tail ---
Connection to orkj647.iego.vip closed by remote host.


--- agent stdout tail ---
